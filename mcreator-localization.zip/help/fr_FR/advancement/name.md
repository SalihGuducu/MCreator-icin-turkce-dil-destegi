Le nom de l'avancement.
S'il n'a pas de parent (avancement racine), alors ce sera le nom du chemin.
