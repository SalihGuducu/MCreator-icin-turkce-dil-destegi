Ce paramètre masque l'avancement dans l'onglet Avancement jusqu'à ce qu'il soit terminé.
