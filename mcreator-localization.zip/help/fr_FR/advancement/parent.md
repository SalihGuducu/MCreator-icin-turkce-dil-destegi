Il s'agit de l'avancement après lequel votre avancement sera répertoriée.

Vous pouvez utiliser "No parent: root" pour créer un nouveau chemin (nouvel onglet d'avancement).
