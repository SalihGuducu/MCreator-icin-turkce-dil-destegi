Vous pouvez choisir une fonction à exécuter lorsque le joueur termine l'avancement avec ce paramètre.
