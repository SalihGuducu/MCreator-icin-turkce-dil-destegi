Recettes à débloquer lorsque le joueur termine l'avancement.
