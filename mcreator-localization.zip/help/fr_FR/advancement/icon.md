L'icône apparaît dans l'onglet Progrès.

S'il s'agit d'un parent racine, ce sera également l'icône d'avancement.

Seuls les éléments sont pris en charge ici. Les blocs sans élément ne peuvent pas être affichés sous forme d'icône.
