Afficher l'avancement en haut à droite de l'écran lorsque le joueur termine l'avancement.
