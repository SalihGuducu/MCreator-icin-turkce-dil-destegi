C'est là que vous mettez des informations sur la façon d'accomplir la tâche.
