Le joueur recevra certains objets de la table de butin sélectionnée définie dans ce champ
lorsque l'avancement est terminé.
