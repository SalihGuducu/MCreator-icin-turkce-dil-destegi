C'est le type de réalisation

* La tâche est un type de réalisation de base et est la plus courante.
* L'objectif est un objectif à long terme que vous vous efforcez d'atteindre.
* Le défi consiste à tester un joueur ou à le défier à quelque chose.
