C'est le nombre de points d'expérience que le joueur recevra après avoir terminé l'avancement.
