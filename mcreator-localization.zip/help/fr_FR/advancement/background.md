Si votre avancement est le premier d'un nouveau chemin, vous pouvez choisir l'arrière-plan de l'onglet Avancement avec cette option.
