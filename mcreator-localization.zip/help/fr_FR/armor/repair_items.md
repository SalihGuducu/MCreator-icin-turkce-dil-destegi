Le paramètre Réparer les éléments contrôle quels éléments peuvent être utilisés pour réparer l'armure à l'intérieur de l'enclume.
