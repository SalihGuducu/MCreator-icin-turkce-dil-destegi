Ce paramètre définit la durabilité de l'armure et est effectivement appliqué comme:

* casque: max_damage_absorbed * 13
* plastron: max_damage_absorbed * 15
* jambières: max_damage_absorbed * 16
* bottes: max_damage_absorbed * 11

L'armure vanilla utilise les facteurs suivants:

* armure en cuir: 5
* armure de cotte de mailles: 15
* armure d'or: 7
* armure de diamant: 33
