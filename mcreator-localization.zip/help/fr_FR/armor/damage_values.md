Ces nombres définissent à quel point les dommages causés à l'entité
sera réduit d'une pièce d'armure donnée.
