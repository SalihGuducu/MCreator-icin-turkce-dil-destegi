La fréquence à laquelle des enchantements rares peuvent être enchantés sur cette armure.
Plus l'enchantabilité est élevée, meilleurs sont les enchantements que vous obtiendrez lors de l'enchantement de l'armure.

Valeurs Vanilla:

* Armure en cuir: 15
* Armure de cotte de mailles: 12
* Armure de fer: 9
* Armure d'or: 25
* Armure de diamant: 10
