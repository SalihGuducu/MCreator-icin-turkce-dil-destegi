Lorsqu'une entité a les leggings équipés, la procédure sera exécutée à chaque tick.

L'entité passée est l'entité portant l'armure, la pile d'objets transmise est la pile d'objets de l'armure.
