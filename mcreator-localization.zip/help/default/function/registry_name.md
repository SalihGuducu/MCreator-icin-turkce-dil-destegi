You can write your function name in one word or with several words with underscore(s).

Examples:
* advancement
* advancement_biome_reward