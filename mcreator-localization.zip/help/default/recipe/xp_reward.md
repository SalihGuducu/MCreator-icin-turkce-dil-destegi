This parameter controls how many experience points the player will receive after completing the recipe.

This parameter is only used with cooking recipes.