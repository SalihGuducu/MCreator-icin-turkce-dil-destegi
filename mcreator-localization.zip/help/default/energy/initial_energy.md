Set the default value of the energy element (block, item, ...).

This is the energy your element will have when a player places it in the world, the element is naturally
spawned or otherwise appears in the world).