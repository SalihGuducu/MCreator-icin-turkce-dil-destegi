This parameter controls near which biomes your biome will spawn. Biomes of the same type tend to
spawn together and share the same chance pool when generating.

* ICY will make your biome spawn near biomes like Snowy Taiga.
* COLD will make your biome spawn near biomes like Mountains are the Taiga.
* WARM will make your biome spawn near biomes like Plains, the Forest, etc.
* DESERT will make your biome spawn near biomes like Badlands and the Desert.