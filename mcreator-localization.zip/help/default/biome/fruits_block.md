This parameter controls the block used for fruit like the Cocoa Beans with the Jungle trees in case custom trees are enabled.

Select air block to disable tree fruits.