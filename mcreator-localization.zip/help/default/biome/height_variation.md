This parameter controls the height variation of this biome.

Lower values will make this biome more even and flat, while big values will make this biome
very dynamic in terrain.