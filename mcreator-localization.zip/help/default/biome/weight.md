This paremeter controls how many times your biome will spawn on 1024 
of the same biome type (ICY, COLD, WARM and DESERT).