Select the entities to spawn naturally inside your biome. 

Select only passive or hostile mobs. Don't select the player or special entities here as this might
cause the world to crash when trying to spawn such entities.