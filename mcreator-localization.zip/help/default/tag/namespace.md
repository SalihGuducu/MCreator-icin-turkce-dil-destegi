This parameter defines the way the tag will function.

* **forge:** is a replacement for Ore Dictionary for tags. 
They can be used to give other mod creators access to their mod with your mod if you provide them with the tag name.
* **minecraft:** is used to add custom blocks or items to vanilla tag groups. 
For example, adding your mod logs to Minecraft's log group (by setting name to logs and namespace to minecraft).
* **mod:** is used for grouping mod elements in your mod for internal use.