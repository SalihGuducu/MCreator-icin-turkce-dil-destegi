When the bullet hits a player, it will execute the selected procedure.

Keep in mind this procedure might trigger when the bullet hits the entity firing the bullet too.