Bullet model is the model of your ranged item.

This parameter will override item for texture parameter when used.