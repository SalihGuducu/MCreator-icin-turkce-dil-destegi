Check this option to enable an enchanted book of your enchantment. 

You can't define the Creative tab, as it is defined by the enchantment type you have defined at the beginning.