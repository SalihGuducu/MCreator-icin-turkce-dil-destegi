A treasure enchantment cannot be obtained in the enchanting table. 

It can only be found in a loot tables, like MENDING or more recently, SOUL SPEED.