This value will be multiplied with the level of the enchantment (that the item has currently) 
to get the number of damage your enchantment will protect.

For example, PROTECTION has a value of 1, so for the first level, the enchantment will 
protect the player of 1 damage as 1 (level) * 1 (your value) = 1.