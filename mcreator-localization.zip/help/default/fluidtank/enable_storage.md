Check this option to enable the storage of fluid.

Blocks need to have tile entity enabled for the fluid tank system to work properly.