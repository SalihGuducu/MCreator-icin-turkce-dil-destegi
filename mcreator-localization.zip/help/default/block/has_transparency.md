Check this parameter if your block is not a solid cube, but has either custom shape or transparent parts
of the texture.