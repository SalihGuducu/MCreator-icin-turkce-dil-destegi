Triggers a procedure when a block next to this one is updated (blockstate changes, new block is placed or 
a block is removed).