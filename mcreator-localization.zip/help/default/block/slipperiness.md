This parameter controls how slippery the block is.

Default value used by most of the blocks is 0.6