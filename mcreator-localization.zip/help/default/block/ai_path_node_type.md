This parameter controls how the block will be "seen" by the AI path navigators of the mobs.

Different AI path node types lead to different decisions on how to proceed with the movement when
near block, depending on the AI path node type.