This parameter controls the power bonus that the block has for the enchanting table. 

The power bonus of the bookshelf is 1, of normal blocks, it is 0.