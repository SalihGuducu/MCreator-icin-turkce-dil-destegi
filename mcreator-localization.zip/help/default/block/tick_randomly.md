Blocks naturally generated will usually not tick by default, unless tick randomly is used.

This parameter makes block tick randomly, where speed is controled by a global world tick
parameter.

This type of ticking is used by plants, for example.