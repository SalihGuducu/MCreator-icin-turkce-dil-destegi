If this parameter is checked, redstone dust will always connect to 
this block (similar to the Redstone Blocks).