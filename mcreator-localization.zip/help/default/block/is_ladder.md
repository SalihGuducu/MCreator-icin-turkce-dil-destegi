If checked, entities will be able to climb on the block. 

The block's width and depth need to be less than 1 for this parameter to work,
so the collisions in the block are detected properly. Change the bounding box
setting to match this if this parameter is used.

Vanilla examples: Ladder and Vines