This parameter should only be used in combination with transparent blocks.

If this is checked, the block won't display the fluid texture when submerged, similar to glass blocks.

This option doesn't work with versions prior to 1.15.2