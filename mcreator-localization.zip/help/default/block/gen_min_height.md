This parameter controls the minimum Y height that this block can generate in.

Vanilla minimum Y levels heights:
* Coal Ore - 1
* Iron Ore - 5
* Gold Ore - 1
* Redstone Ore - 1
* Diamond Ore - 1
* Emerald Ore - 4
* Lapis Lazuli - 1