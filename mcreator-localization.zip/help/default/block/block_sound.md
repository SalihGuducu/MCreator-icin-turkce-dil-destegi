Sound group that defines this block. This parameter affects sounds as block placement sound,
block breaking sound and sound played when walking on the block.