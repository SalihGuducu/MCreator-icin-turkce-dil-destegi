Block material defines some base block properties such as
reaction to pistons, water, plant growing options and more.

If you intend to use the block for ore, select ROCK material
so the harvest level is properly applied.

Click [here](https://mcreator.net/wiki/materials) to read more about materials.