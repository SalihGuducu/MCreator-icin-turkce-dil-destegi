This parameter controls the maximum Y height that this block can generate in.

Vanilla maximum Y levels heights:
* Coal Ore - 125
* Iron Ore - 40
* Gold Ore - 32
* Redstone Ore - 16
* Diamond Ore - 16
* Emerald Ore - 32
* Lapis Lazuli - 31