When the command is executed, the selected procedure here will be executed.

Commands usually run on the server-side only.