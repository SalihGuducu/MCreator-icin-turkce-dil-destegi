The player will need to, at least, have this permission level to execute the command. 1 is the basic permission level, and 4 is the highest. 

Check [this page](https://mcreator.net/wiki/command-permission-levels) to see which command can be executed with each permission level.