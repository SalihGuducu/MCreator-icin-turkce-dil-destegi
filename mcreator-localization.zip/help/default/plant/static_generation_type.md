This parameter controls how your static plant will be generated. 

* **Flower:** The plant will be generated like veins.
* **Grass:** The plant will be generated in masses.