This parameter controls what color your plant will appear as on maps. 

If it's set to Default, the color will be FOLIAGE.