Click on the dropdown list and choose the "category" of the loot table. It doesn't define the loot table type. 

It's only to standardize loot table names. Use blocks/registry_name for block loot tables for example.