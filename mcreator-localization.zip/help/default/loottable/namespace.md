If you want to change a vanilla loot table, you have to choose "minecraft", 
but if you want to create a new loot table for your mod elements, choose "mod".