This parameter defines armor durability and is effectively applied as:

* helmet: max_damage_absorbed * 13
* chestplate: max_damage_absorbed * 15
* leggings: max_damage_absorbed * 16
* boots:  max_damage_absorbed * 11

Vanilla armor uses the following factors:

* leather armor: 5
* chainmail armor: 15
* gold armor: 7
* diamond armor: 33