How common rare enchantments can be enchanted on this armor. 
The higher the enchantability, the better enchantments you will get when enchanting the armor.

Vanilla values:

* Leather armor: 15
* Chainmail armor: 12
* Iron armor: 9
* Gold armor: 25
* Diamond armor: 10