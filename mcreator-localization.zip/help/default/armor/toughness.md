Toughness is a value that will increase the protection of the armor. 

The diamond armor has a toughness of 2.0 (for a total of 8.0) 
and the Netherite armor has a toughness of 3.0 (for a total of 12.0).