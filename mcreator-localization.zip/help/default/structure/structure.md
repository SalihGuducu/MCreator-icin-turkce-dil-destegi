Current vanilla limit for a single structure is 32x32x32 blocks for performance reasons.

Structure block is a built-in vanilla block that can save builds as .NBT structures. 

You can use structural voids to allow the structure to let other blocks override air blocks in your structure 
when it is generated. For example, if you want your structure to be buried on the inside you can fill the 
inside of the structure with structure voids using the /fill command to allow natural blocks to 
spawn where the voids are. Voids will not generate in your structures they are just placeholder blocks to let other 
blocks override the area on generation.