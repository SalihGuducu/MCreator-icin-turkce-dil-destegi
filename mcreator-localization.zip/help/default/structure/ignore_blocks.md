This option will specify which blocks not to place (ignore) when generating the structure.

Select air here in order to not place air blocks of your structure. This will make the structure
integrate better with the environment, but in case of cave based structures, you will likely want to
place the air too.