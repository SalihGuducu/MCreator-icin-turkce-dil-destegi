This parameter controls:
 
* how many blocks on the X-axis compared to the initial spawn point the structure will be generated.
* how many blocks above or below initial spawn point the structure will be generated.
* how many blocks on the Z-axis compared to the initial spawn point the structure will be generated.