Burn Time indicates how many ticks a given fuel will last. 

Coal takes 80 seconds to completely burn away and so it is 1600 ticks. (The default setting) This is just enough to smelt 8 items. This means that 20 ticks are 1 second of burning time.

To measure how many ticks you need to use, use this equation: 

`#of ticks needed = #of items you want the fuel to smelt * 20`

Click [here](https://mcreator.net/wiki/burn-time-fuels) for a list of burn times of commonly used items for smelting in Minecraft.

