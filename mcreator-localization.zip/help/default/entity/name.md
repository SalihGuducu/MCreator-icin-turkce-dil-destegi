Mob name is used in death messages,
is shown in in-game menus and other
places where visual name display is possible.