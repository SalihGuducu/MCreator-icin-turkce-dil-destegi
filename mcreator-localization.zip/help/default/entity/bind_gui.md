If you want to bind a GUI to your entity (to make a villager or custom horse-like inventory, for example), 
check this box to enable the inventory and bind it to a selected GUI.