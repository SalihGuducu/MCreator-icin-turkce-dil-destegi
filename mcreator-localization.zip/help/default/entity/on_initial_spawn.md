Triggers the procedure when the entity spawns.

Keep in mind some procedure blocks might not work properly in this trigger during early world generation.