The minimum and maximum set here set the size of groups that the mob will spawn in. 

Be warned that mobs that try to spawn in groups of over 20 will struggle to do so (mobs will rarely spawn).