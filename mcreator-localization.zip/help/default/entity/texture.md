Texture of your entity. Make sure the texture is compatible with the model you selected.

Biped models, for example, only support 64x32 biped type textures.