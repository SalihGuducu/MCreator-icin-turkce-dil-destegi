The attack knockback defines the knockback value of each attack of this entity
Most vanilla entities do not use it. Some do, such as the ravager, which has a knockback value of 1.5.
