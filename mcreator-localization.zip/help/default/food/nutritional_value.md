The nutritional value is how much this food feeds the player. 

1 is 1/2 in the food bar. 20 is the full food bar.