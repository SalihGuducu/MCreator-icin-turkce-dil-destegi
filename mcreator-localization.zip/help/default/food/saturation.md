Saturation is the first statistic to decrease when a player performs energy-intensive actions, 
and it must be completely depleted before the visible hunger meter begins decreasing.