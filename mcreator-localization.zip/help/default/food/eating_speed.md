Eating speed is the time in ticks that the player takes to eat one item of the food. 

1 second = 20 ticks