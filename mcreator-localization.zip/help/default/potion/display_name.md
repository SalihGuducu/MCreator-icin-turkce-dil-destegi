This parameter controls is the name of the potions and the tipped arrows. 

You don't have to write Potion of or Arrow of. MCreator automatically includes them.