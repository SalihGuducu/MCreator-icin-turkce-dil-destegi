The rarity affects only the color of the item's name.
* Common: White
* Uncommon: Yellow
* Rare: Aqua
* Epic: Light Purple