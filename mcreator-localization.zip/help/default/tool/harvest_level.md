The tool with given harvest level (tier) can only break blocks with the same tier or below.

* 0 is hand/wood
* 1 is stone
* 2 is iron
* 3 is diamond

You can define larger tiers than diamond too by setting the tier to 4 or larger.