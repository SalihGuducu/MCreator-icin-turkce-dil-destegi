Use this field to define biomes, where the spawning should happen.

If the list is empty, no biome restriction will be set and spawning will
occur in all biomes.